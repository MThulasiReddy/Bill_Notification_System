#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAME_LENGTH 50

struct pQueue {
    char name[MAX_NAME_LENGTH];
    int date;
    int month;
    int year;
    float bill;
    struct pQueue* next;
} *head = NULL, *current, *p, *q;

int d, m, y;

int checkDate(int d1, int m1, int y1, int d2, int m2, int y2) {
    if (d2 < d1) {
        if (m2 == 3) {
            if (y2 % 100 != 0 && y2 % 4 == 0 || y2 % 400 == 0)
                d2 = d2 + 29;
            else
                d2 = d2 + 28;
        } else if (m2 == 5 || m2 == 7 || m2 == 10 || m2 == 12)
            d2 = d2 + 30;
        else
            d2 = d2 + 31;
        m2 = m2 - 1;
    }
    if (m2 < m1) {
        y2 = y2 - 1;
        m2 = m2 + 12;
    }
    y = y2 - y1;
    m = m2 - m1;
    d = d2 - d1;
    if (y < 0 || m < 0 || d < 0)
        return -1;
    else
        return 1;
}

void pEnq() {
    current = (struct pQueue*)malloc(sizeof(struct pQueue));
    current->next = NULL;
    printf("Enter name of the bill, bill amount, due date, month, year: ");
    scanf("%s %f %d %d %d", current->name, &current->bill, &current->date, &current->month, &current->year);
    if (head == NULL)
        head = current;
    else if (checkDate(current->date, current->month, current->year, head->date, head->month, head->year) == 1) {
        current->next = head;
        head = current;
    } else {
        p = head;
        q = head;
        while (p != NULL && (checkDate(p->date, p->month, p->year, current->date, current->month, current->year) == 1)) {
            q = p;
            p = p->next;
        }
        current->next = p;
        q->next = current;
    }
    printf("Bill added successfully!\n");
}

void display() {
    int pd, pm, py;
    printf("Enter present date, month, year: ");
    scanf("%d %d %d", &pd, &pm, &py);
    if (head == NULL)
        printf("No pending bills!\n");
    else {
        p = head;
        while (p != NULL) {
            if (checkDate(p->date, p->month, p->year, pd, pm, py) == 1)
                printf("%s of %.2f$ is pending for %d years, %d months, %d days!\n", p->name, p->bill, y, m, d);
            p = p->next;
        }
    }
}

int main() {
    int ch;
    printf("-------------------------------------------------------------\n");
    printf("               - BILL NOTIFICATION SYSTEM -                  \n");
    printf("-------------------------------------------------------------\n");

    while (1) {
        printf("\n1. Add a new bill   2. Display pending bills   3. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &ch);

        switch (ch) {
            case 1:
                pEnq();
                break;
            case 2:
                display();
                break;
            case 3:
                exit(0);
            default:
                printf("Invalid choice!\n");
        }
    }

    return 0;
}
